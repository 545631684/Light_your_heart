// const cons = require("consolidate");
import request from "../../../network/request"
//index.js
//获取应用实例


Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    arr:[],
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    isShow:false
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },

  //列表数据
  getListData: function () {
        var token = wx.getStorageSync('token')
        request("/public/geticon",'get',{
          ItemType: 0
        },token).then(res=>{
          console.log(res)
          this.setData({
            list:res.data.data
          })
          var arr = [];
            for (let index = 0; index < res.data.data.length; index++) {
              arr.push(false)
            };
            this.setData({
              arr
            })
        })
      },
  onLoad: function () {   
    this.getListData();
  },
  
  on: function (e) {
    console.log(e);
    var arr = this.data.arr;
    var index= e.target.dataset.idx
    var name= e.target.dataset.name
    if(arr[index] == name){
      arr[index] = ""
    }else{
      arr[index] = name;
    }
    var num = 0
    var list = []
    arr.forEach(ev=>{
      if(ev != false){
        num ++
        list.push(ev)
      }
    })
    console.log(list)
    console.log(arr,num)    
    this.setData({
      arr,
      num
    })    
    
    
  },
  commit(){
    var num = this.data.num
    var MemberCode = wx.getStorageSync('MemberCode')
    var token = wx.getStorageSync('token')
    var FId = wx.getStorageSync('FId')
    if(num != 3){
      wx.showToast({
        title: '请选择三项',
        icon:'none'
      })
    }else{
      var data = [
          {
            "FId": FId,
            "IconCode": "06709c8ff9024e7d9047ddb62366682c",
            "MemberCode": MemberCode,
            "Habit": "g1",
            "Explain": "没有描述",
            "IsEffective": true
          }          
        ]
      
      console.log(data)
      console.log(this.data.arr)
      request("/masterhypnotist/memberhabit","post",JSON.stringify(data),token).then(res=>{
        console.log(res)
        wx.setStorageSync('habit', '1111')
        this.setData({
          isShow:true
        })
      })
    }

  },
  close(){
    wx.navigateTo({
      url: '/sleep-mainPages/pages/college/college'
    })
  }

})