// components/my-f1/my-f1.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    goods:[
      {
        text:"光亮",
        id:0,
        checked:false
      },
      {
        "text":"不适",
        "id":1,
        "checked":false
      },
      {
        "text":"压力",
        "id":2,
        "checked":false
      },
      {
        "text":"床伴",
        "id":3,
        "checked":false
      },
      {
        "text":"饱餐",
        "id":4,
        "checked":false
      },
      {
        "text":"认床",
        "id":5,
        "checked":false
      },
      {
        "text":"温度",
        "id":6,
        "checked":false
      },
      {
        text:"噪音",
        id:7,
        checked:false
      }
    ],
  },

  /**
   * 组件的方法列表
   */
  methods: {
    choose(e) {
      console.log(e)
	    let index = e.currentTarget.id
	    var bool = this.data.goods[index].checked
	    this.setData({
        ['goods[' + index + '].checked']: !bool,
      })
      this.triggerEvent("choose",!bool);
    }
  }
})
